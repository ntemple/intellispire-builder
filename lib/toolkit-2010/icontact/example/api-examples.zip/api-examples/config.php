<?php

$GLOBALS['config'] = array(
	'apiUrl'   => 'https://app.beta.icontact.com/icp',
	'username' => 'your_username',
	'password' => 'your_password',
	'appId'    => 'your_appId',
);

?>
