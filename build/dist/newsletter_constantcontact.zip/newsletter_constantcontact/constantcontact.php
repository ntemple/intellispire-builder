<?php
/*
Plugin Name: Newsletter ConstantContact Newsletter Signup
Plugin URI: http://www.intellispire.com/
Description: Connect WordPress Registration to ConstantContact
Version:  1.0.0
Author: Intellispire Team
Author URI: http://www.intellispire.com/
License: GPL v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

*/


function newsletter_constantcontact() {
    return uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactNewsletter::instance();
}
newsletter_constantcontact();

class uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactNewsletter {

    static $instance;

    // Globals
    var $version   = '1.0.0';
    var $item_name = 'ConstantContact';
    var $author    = 'Intellispire';
    var $update_server = 'http://www.intellispire.com';
    var $prefix    = 'constantcontact';

    // Classes
    var $optionsPage;  // uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactNewsletterSettingsPage
    var $updater;      // uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactNewsletterProEDD_SL_Plugin_Updater
    var $coreclass;

    var $params;

    /** @var array */
    var $options_key;
    var $options;


    var $json_params = '[{"name":"list","type":"text","default":"1","label":"Order #","description":"Which list to add the contact to?"},{"name":"apikey","type":"text","default":"","label":"API Key","description":"API Access Key of ConstantContact service. You can obtain this key using this link: http:\/\/community.constantcontact.com\/t5\/Documentation\/API-Keys\/ba-p\/25015"},{"name":"username","type":"text","default":"","label":"Username","description":"ConstantContact Account Username"},{"name":"password","type":"password","default":"","label":"Password","description":"ConstantContact Account Password"}]';

    public static function instance()
    {
        if ( ! isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', array($this, 'init'));
    }

    function init() {
        // Globals
        $this->options_key = $this->prefix . '_options';
        $this->options = get_option($this->options_key);
        $this->params = $this->setParams();

        // Includes
        // require_once( "updater.php");

        $this->update();
        if (is_admin()) {
            $this->setup_admin();
        }

        // Actions
        add_action('register_form',  array($this, 'registration_fields'), 100);
        add_action('user_register', array($this, 'check_for_email_signup'), 10, 2);

    }

    function get_option($key, $default = null) {
        if (isset($this->options[$key])) {
            return trim($this->options[$key]);
        } else {
            return $default;
        }
    }

    function set_option($key, $value) {
        $this->options[$key] = $value;
        update_option($this->options_key, $this->options);
    }

    private function setup_admin() {

        add_filter($this->prefix . '_update_options', array($this, 'activate_license'));
        $this->optionsPage = new uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactNewsletterSettingsPage($this->item_name, $this->prefix, $this->params);
    }

    function isLicenseValid() {
        $license_valid = $this->get_option('license_valid', '');
        $license_key   = $this->get_option('license_key', '');

        if (! $license_key) return false;

        if ($license_valid == 'valid') {
            return true;
        } else {
            return false;
        }
    }

    function activate_license($options) {

        $old_options = get_option($this->options_key .'_old', array());
        $old_license = isset($old_options['license_key']) ? $old_license = $old_options['license_key'] : '';
        $license_key = isset($options['license_key']) ? $license_key = $options['license_key'] : '';

        if ($license_key != $old_license)  {
            $valid = $this->updater->activate($license_key);
            $options['license_valid'] = $valid;
        }
        return $options;
    }

    private function update() {

        $license_key = $this->get_option('license_key', '');

        $this->updater = new uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactNewsletterProEDD_SL_Plugin_Updater( $this->update_server, __FILE__, array(
                'version' 	=> $this->version, 	   // current version number
                'license' 	=> $license_key, 	   // license key (used get_option above to retrieve from DB)
                'item_name' => $this->item_name,   // name of this plugin
                'author' 	=> $this->author       // author of this plugin
            )
        );
    }

    function setParams() {
        if ($this->isLicenseValid()) {
            $params = json_decode($this->json_params, true);
            array_unshift($params,  array('name' => 'signup_text',       'size' => 50, 'type' => 'text', 'default' => 'Sign up for our mailing list', 'label' => 'Label', 'description' => 'Label for checkbox' ));
        } else {
            $params = array();
        }

        array_unshift($params,  array('name' => 'license_key',       'size' => 50, 'type' => 'text', 'default' => '', 'label' => 'Activation Key', 'description' => 'Enter your activation to activate the plugin.'));
        $this->params = $params;
        return $params;
    }


    /**
     * Add new registration fields the signup form
     */
    function registration_fields()  {
        if (! $this->isLicenseValid()) return;

        $text = $this->get_option('signup_text', 'Sign up for our mailing list');
        $label = isset($options[$this->prefix .'_label']) ? $options[$this->prefix .'_label'] : __($text, $this->prefix);

        $out = "<p>
        <input name='{$this->prefix}_signup' id='{$this->prefix}_signup' type='checkbox' checked='checked'/>
        <label for='{$this->prefix}_signup'>$label</label>
        </p>\n";
        print $out;
    }

    /**
     * checks whether a user should be signed up for the list
     */

    function check_for_email_signup($userid) {
        if (isset($_POST[$this->prefix . '_signup'])) {
            $platform = new uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactPlatform($this);
            $userdata = get_userdata( $userid );
            $platform->notify((array) $userdata->data);
        }
    }
}




/**
 * Create a wordpress OptionsPage from
 * an array of fields.
 */

class uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactNewsletterSettingsPage {

    var $prefix;
    var $params;

    var $PLUGINS_HANDLE;
    var $OPTIONS_HANDLE;
    var $SECTION_HANDLE;

    var $name;
    var $plugin_name;
    var $page_name;

    var $updated = false;

    /**
     * @param $name            Camel Case name of Plugin "AWeber Newsletter"
     * @param $plugin_name     lowercase escaped unique name, usually the directory we're in
     * @param $params
     * @param null $page_name
     */

    function __construct($name, $plugin_name, $params, $page_name = null) {

        $this->name = $name;
        $this->params = $params;
        $this->plugin_name = $plugin_name;
        $this->page_name = $name;
        if ($page_name) {
            $this->page_name = $page_name;
        }

        $prefix = strtolower($this->plugin_name);
        $this->prefix = $prefix;


        $this->PLUGINS_HANDLE = $prefix . "_plugins";
        $this->OPTIONS_HANDLE = $prefix . "_options";
        $this->SECTION_HANDLE = $prefix . "_section";

        $this->updated = get_transient($this->OPTIONS_HANDLE . '_u');

        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_menu', array($this, 'admin_add_page'));
        add_action('admin_notices', array($this, 'admin_notice'));
    }

    function admin_add_page() {
        add_submenu_page ( 'options-general.php', "{$this->name}", $this->page_name, 'manage_options', $this->plugin_name, array($this, 'settings_page'));
    }

    function admin_init() {

        // One settings group for now. Eventually allow split into pages
        add_settings_section($this->SECTION_HANDLE, "{$this->name} Settings", array($this, 'main_section_text'), $this->PLUGINS_HANDLE);

        // We only have one setting
        register_setting ( $this->OPTIONS_HANDLE, $this->OPTIONS_HANDLE, array($this, 'validate') );

        foreach ($this->params as $param) {

            add_settings_field(
                $this->prefix . '_setting_' . $param['name'],
                $param['label'],
                array($this, 'displaySetting'),
                $this->PLUGINS_HANDLE,
                $this->SECTION_HANDLE,
                $param
            );

        }
    }

    /**
     * @param $param create an input widget
     */

    function displaySetting($param) {
        $options = get_option($this->OPTIONS_HANDLE);
        $name =  $param['name'];
        $value = $options[$name];

        if (! $value && isset($param['default'])) $value = $param['default'];

        // Convert complex types into basic types
        switch($param['type']) {
            case 'template_list':
                $template_options = array('0:Let WordPress Choose');
                $templates = get_page_templates();
                foreach($templates as $template_name => $template_filename ) {
                    $template_options[] = "$template_filename:$template_name";
                }
                $param['options'] = $template_options;
                $param['type'] = 'list';
                break;
            case 'date': //@todo make date picker work
                /*
                <link rel="stylesheet" href="<?php echo BRACKETPRESS_CSS_URL ?>jquery-ui.css" type="text/css" />
                <script src="<?php echo BRACKETPRESS_CSS_URL ?>jquery-1.8.3.js"></script>
                <script src="<?php echo BRACKETPRESS_CSS_URL ?>jquery-ui.js"></script>

                                $id = "{$this->prefix}_$name";
                                print "<script type='text/javascript'>$('#$id').datepicker();</script>\n";
                                $param['type'] = 'text';
                */
                break;
        }

        // Handle the basic types
        switch ($param['type']) {

            case 'list':
                echo "<select id='{$this->prefix}_$name' name='{$this->prefix}_options[$name]'>\n";
                foreach ($param['options'] as $option) {
                    list ($v, $o) = explode(':', $option);
                    $selected = '';
                    if ($v == $value) {
                        $selected = "selected='selected'";
                    }
                    print "<option value='$v' $selected>$o</option>\n";
                }
                echo "</select>\n";
                break;
            case 'checkbox':
                $checked = '';
                if ($value == 'TRUE') {
                    $checked = "checked='checked'";
                }
                echo "<input id='{$this->prefix}_$name' name='{$this->prefix}_options[$name]' type='checkbox' value='TRUE' $checked />";
                break;
            case 'text':
            default:
                echo "<input id='{$this->prefix}_$name' name='{$this->prefix}_options[$name]' size='{$param['size']}' xtype='{$param['type']}' value='$value' />";
        }

        if (isset($param['description'])) print "\n<br> " . $param['description'];

    }

    function admin_notice() {
        if ($this->updated) {
            delete_transient($this->OPTIONS_HANDLE . '_u');
            echo '<div class="updated"><p>';
            // printf(__("{$this->name} Settings Updated | <a href='%1$s'>Undo</a>"), '?undo=0');
            echo "{$this->name} Settings Updated.";
            echo '</p></div>';
        }
    }

    function undo() {
        /*
                    add_action('admin_init', 'example_nag_ignore');
                    function example_nag_ignore() {
                        global $current_user;
                        $user_id = $current_user->ID;
                        //  If user clicks to ignore the notice, add that to their user meta
                        if ( isset($_GET['example_nag_ignore']) && '0' == $_GET['example_nag_ignore'] ) {
                            add_user_meta($user_id, 'example_ignore_notice', 'true', true);
                        }
                    }
        */

    }


    function main_section_text() {
        echo "<p>{$this->name} Options</p>";
    }

    function validate($input) {
        $options = get_option($this->OPTIONS_HANDLE, array());
        update_option($this->OPTIONS_HANDLE . '_old', $options); // @todo allow for undo
        set_transient($this->OPTIONS_HANDLE . '_u', 1, 60);

        foreach ($this->params as $param) {
            $name = $param['name'];
            if (isset($input[$name])) $options[$name] = $input[$name];
        }

        $options = apply_filters($this->prefix . '_update_options', $options);

        return $options;
    }

    function settings_page() {
        ?>
<style type="text/css">
    .form-table th {text-align: right}
</style>
    <div class="wrap">
        <?php screen_icon(); ?>
        <h2><?php print $this->name ?></h2>
        <form method="post" action="options.php">
            <?php settings_fields($this->OPTIONS_HANDLE); ?>
            <?php do_settings_sections($this->PLUGINS_HANDLE); ?>
            <input name="Submit" type="submit" name="cmd_update" value="<?php esc_attr_e('Save Changes'); ?>" />
        </form>
    </div>
    <?php
    }
}


class uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactPlatform {

    var $debug = false;
    var $plugin = null;

    function __construct($plugin) {
        $this->plugin = $plugin;
    }

    // Implemented in the plugin
    function get_param($key, $default = null) {
        return $this->plugin->get_option($key, $default);
    }

    function set_param($key, $value) {
        return $this->plugin->set_option($key, $value);
    }

    /**
     * The main autoresponder function.
     * This function calls out to the appropriate auto-responder class
     * @param mixed $user: The normalized user array
     */
    function notify($user) {
        $success = false;

        $userdata = $this->normalize($user);

        try {
            $ar = new uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactMailClass();
            $success = $ar->notify($this, $userdata);
        } catch(Exception $e) {
            $this->setResponse($e);
        }

        $this->save();
        return $success;
    }

    function normalize($data) {

        $userdata = array();
        foreach ($userdata as $key => $value) {
            if (is_scalar($value)) {
                $userdata[$key] = $value;
            }
        }

        $userdata['email'] = $data['user_email'];
        $userdata['name'] =  $data['display_name'];

        return $userdata;
    }

    function save() {
        // Save results
    }


    function warn($msg) {
        // Emit warning message
    }

    function sendmail($emailFrom, $nameFrom, $recipient, $subject, $msg) {

        $subject = str_replace('Joomla ', '', $subject); // This isn't Joomla!

        $headers = array();
        $headers[] = "From: $nameFrom <$emailFrom>";
        wp_mail($recipient, $subject, $msg, $headers);
    }

    function setRequest($val) {
        $val = substr($val, 0, 2048); // protect from large requests
        $this->set_param('request', $val);
        return true;
    }

    function setResponse($val) {
        $val = substr($val, 0, 2048); // protect from large responses
        $this->set_param('response', $val);
        return true;
    }

    function setDebug($val) {
        static $msg = '';
        if (!$this->debug) return true;

        $msg .= $val . "\n";
        $msg = substr($msg, 0, 2048); // protect from large responses
        $this->set_param('debug', $val);

        return true;
    }

    function curl_post($url, $data) {
        if (!function_exists('curl_version')) {
            throw new Exception('Curl not loaded, cannot retrieve file.');
        }

        if (is_array($data)) {
            $data = http_build_query($data);
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 1); // RETURN HTTP HEADERS
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);

        $contents = curl_exec($ch);
        curl_close($ch);

        return $contents;
    }

    function url_retrieve($url, $query = '') {
        if (is_array($query)) $query = http_build_query($query);
        if ($query) $url .= '?' . $query;
        return $this->url_retrieve_curl($url);
    }


    function url_retrieve_curl($url, $timeout = 30) {

        if (!function_exists('curl_version')) {
            throw new Exception('Curl not loaded, cannot retrieve file.');
        }

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);

        // Getting binary data
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
        $contents = curl_exec($ch);
        curl_close($ch);
        return $contents;
    }

}


/**
 * Allows plugins to use their own update API.
 * 
 * @author Pippin Williamson
 * @version 1.0
 */
class uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactNewsletterProEDD_SL_Plugin_Updater {
	private $api_url = '';
	private $api_data = array();
	private $name = '';
	private $slug = '';

	/**
	 * Class constructor.
	 *
	 * @uses plugin_basename()
	 * @uses hook()
	 * 
	 * @param string $_api_url The URL pointing to the custom API endpoint.
	 * @param string $_plugin_file Path to the plugin file.
	 * @param array $_api_data Optional data to send with API calls.
	 * @return void
	 */
	function __construct( $_api_url, $_plugin_file, $_api_data = null ) {
		$this->api_url = trailingslashit( $_api_url );
		$this->api_data = urlencode_deep( $_api_data );
		$this->name = plugin_basename( $_plugin_file );
		$this->slug = basename( $_plugin_file, '.php');
		$this->version = $_api_data['version'];
	
		// Set up hooks.
		$this->hook();
	}
	
	/**
	 * Set up Wordpress filters to hook into WP's update process.
	 * 
	 * @uses add_filter()
	 * 
	 * @return void
	 */
	private function hook() {
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'pre_set_site_transient_update_plugins_filter' ) );
		add_filter( 'plugins_api', array( $this, 'plugins_api_filter' ), 10, 3);
	}

	/**
	 * Check for Updates at the defined API endpoint and modify the update array.
	 *
	 * This function dives into the update api just when Wordpress creates its update array,
	 * then adds a custom API call and injects the custom plugin data retrieved from the API.
	 * It is reassembled from parts of the native Wordpress plugin update code.
	 * See wp-includes/update.php line 121 for the original wp_update_plugins() function.
	 *
	 * @uses api_request()
	 *
	 * @param array $_transient_data Update array build by Wordpress.
	 * @return array Modified update array with custom plugin data.
	 */
	function pre_set_site_transient_update_plugins_filter( $_transient_data ) {


		if( empty( $_transient_data ) ) return $_transient_data;

		$to_send = array( 'slug' => $this->slug );

		$api_response = $this->api_request( 'get_version', $to_send );

		if( false !== $api_response && is_object( $api_response ) ) {
			if( version_compare( $this->version, $api_response->new_version, '<' ) ) 
				$_transient_data->response[$this->name] = $api_response;
	    }
		return $_transient_data;
	}

	
	/**
	 * Updates information on the "View version x.x details" page with custom data.
	 * 
	 * @uses api_request()
	 * 
	 * @param mixed $_data
	 * @param string $_action
	 * @param object $_args
	 * @return object $_data
	 */
	function plugins_api_filter( $_data, $_action = '', $_args = null ) {
		if ( ( $_action != 'plugin_information' ) || !isset( $_args->slug ) || ( $_args->slug != $this->slug ) ) return $_data;
	
		$to_send = array( 'slug' => $this->slug );

		$api_response = $this->api_request( 'plugin_information', $to_send );
		if ( false !== $api_response ) $_data = $api_response;

		return $_data;
	}

	/**
	 * Calls the API and, if successfull, returns the object delivered by the API.
	 * 
	 * @uses get_bloginfo()
	 * @uses wp_remote_post()
	 * @uses is_wp_error()
	 * 
	 * @param string $_action The requested action.
	 * @param array $_data Parameters for the API action.
	 * @return false||object
	 */
	private function api_request( $_action, $_data ) {

		$data = array_merge( $this->api_data, $_data );
		if( $data['slug'] != $this->slug )
			return;

		$api_params = array( 
			'edd_action' 	=> $_action,
			'license' 		=> $data['license'], 
			'name' 			=> $data['item_name'],
            'item_name'     => $data['item_name'],
			'slug' 			=> $this->slug,
			'author'		=> $data['author']
		);
		$response = wp_remote_post( $this->api_url, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

		if ( !is_wp_error( $response ) ) {
			$response = json_decode( wp_remote_retrieve_body( $response ) );
			if( $response )
				$response->sections = maybe_unserialize( $response->sections );
			return $response;
        } else {
			return false;
        }
	}

    /**
     * Activate a license key
     * @param $license
     * @return bool
     */

    public function activate($license) {

        $license = sanitize_text_field($license);
        $response = $this->api_request('activate_license', array('license' => $license, 'slug' => $this->slug));
        if ($response) {
            return $response->license;
        } else {
            return false;
        }
    }
}



class uedf84a411d404d2fa43a22f3fecb04ce_ConstantcontactMailClass {

    /**
     * The main autoresponder function.
     * This function must:
     * - retrieve any parameters in order to create the "request" to send to the autoresponder, which list, etc
     * - store the request so the webmaster can se what was sent
     * - store any error or success messages in the response
     * @param Platform $platform: the platform API
     * @param array $user: The normalized user array
     */

    function notify($platform, $user) {

        $apikey   = $platform->get_param('apikey');
        $username = $platform->get_param('username');
        $password = $platform->get_param('password');
        $list     = $platform->get_param('list');

        if (is_null($apikey) || empty($apikey)){
            return $platform->warn("The created account has not been exported to ConstactContact service due to invalid API key. Please, re-check your settings");
        }

        $contact = array(
            'EmailAddress' => $user['email'],
            'FirstName' => $user['first_name'],
            'LastName' => $user['last_name'],
        );

        $post = $this->add_contact_xml($contact, $list, $username);

        $auth = $apikey . '%' . $username . ':' . $password;
        $api_url = 'https://api.constantcontact.com/ws/customers/' . $username . '/contacts';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, Array("Content-Type:application/atom+xml"));
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 120);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, $auth);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST , 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER , 0);
        $contents = curl_exec($ch);
        $response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $platform->setRequest($post);
        $platform->setResponse($contents);

        $warning = $this->validateServiceResponse($contents);
        if ($warning) {
            $platform->warn($warning);
            return false;
        }
        return true;
    }

    function add_contact_xml($data, $list, $username) {
        $updated = date('Y-m-d\TH:i:s\Z');
        $post = <<<end
<entry xmlns="http://www.w3.org/2005/Atom">
	<title type="text"> </title>
	<updated>{$updated}</updated>
	<author></author>
	<id>data:,none</id>
	<summary type="text">Contact</summary>
	<content type="application/vnd.ctct+xml">
		<Contact xmlns="http://ws.constantcontact.com/ns/1.0/">
			<OptInSource>ACTION_BY_CUSTOMER</OptInSource>

end;

        foreach ($data as $key => $val)
            $post .= "\t\t\t<$key>{$val}</$key>\n";

        $post .= <<<end
      <ContactLists>
        <ContactList id="http://api.constantcontact.com/ws/customers/{$username}/lists/{$list}" />
			</ContactLists>
		</Contact>
	</content>
</entry>
end;
        return $post;
    }

    /**
     * The function checks responses from ConstantContact service and returns warning messages
     * in case of different kind of problems
     *
     * @param string $response
     * @return boolean
     */
    function validateServiceResponse($response)  {

        if ($response == null || empty($response)) {
            return "ConstantContact service didn't return any responses after the sent request";
        }

        $API_KEY_NOT_FOUND_MSG = "Application data not found for key";

        // 1. We need to verify that API key has been correctly entered
        if (preg_match("/$API_KEY_NOT_FOUND_MSG/i", $response)){
            return "ConstantContact service has reported about invalid or expired API key";
        }

        return false;
    }


}

